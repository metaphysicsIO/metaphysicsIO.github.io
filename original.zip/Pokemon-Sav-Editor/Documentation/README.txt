This is just documentation I made along the way. It's useful for me during dev,
but it may also be useful to others. 

The name should make it self-explanatory what they are. But I will probably
properly document these as time goes on.


