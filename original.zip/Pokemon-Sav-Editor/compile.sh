g++ -Wall main.cpp SavEdit.cpp PrivateAccess.cpp UserOptions.cpp TextOptions.cpp -o SE.o
